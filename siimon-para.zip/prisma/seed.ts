/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  // Admin User
  await prisma.user.upsert({
    where: { email: 'admin@siimonpara.com' },
    update: {},
    create: {
      email: 'admin@siimonpara.com',
      password: hashedPassword,
      name: 'Admin Siimon',
      role: 'ADMIN',
    },
  });

  // Sample Clients
  const client1 = await prisma.client.create({
    data: {
      code: 'CL001',
      name: 'Pharmacie de la Paix',
      city: 'Paris',
      phone: '0123456789',
    }
  });

  // Sample Products
  await prisma.product.createMany({
    data: [
      { code: 'PR001', name: 'Dolirhume Tab', sellPrice: 5.50, buyPrice: 3.20, stock: 100 },
      { code: 'PR002', name: 'Biafine 186g', sellPrice: 8.90, buyPrice: 5.10, stock: 50 },
      { code: 'PR003', name: 'Eau Micellaire 500ml', sellPrice: 12.00, buyPrice: 7.50, stock: 200 },
    ]
  });

  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
