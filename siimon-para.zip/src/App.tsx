/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './pages/LoginPage';
import { BonLivraisonPage } from './pages/BonLivraisonPage';
import { DashboardLayout } from './components/DashboardLayout';

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { token, isLoading } = useAuth();
  if (isLoading) return null;
  if (!token) return <Navigate to="/login" />;
  return <>{children}</>;
};

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute>
            <DashboardLayout title="Tableau de Bord">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 {[
                   { label: "Ventes du jour", value: "14,500 DH", trend: "+12%" },
                   { label: "Commandes en cours", value: "8", trend: "-2" },
                   { label: "Nouveaux Clients", value: "3", trend: "Stable" },
                 ].map((stat, i) => (
                   <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                     <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">{stat.label}</p>
                     <div className="flex items-end justify-between">
                       <p className="text-3xl font-serif font-bold text-slate-800">{stat.value}</p>
                       <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">{stat.trend}</span>
                     </div>
                   </div>
                 ))}
              </div>
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/dashboard/vente/bon-livraison" 
        element={
          <ProtectedRoute>
            <BonLivraisonPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/dashboard/achat/reception" 
        element={
          <ProtectedRoute>
            <BonLivraisonPage />
          </ProtectedRoute>
        } 
      />
      <Route path="/" element={<Navigate to="/dashboard" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

