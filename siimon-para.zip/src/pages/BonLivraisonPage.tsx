/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Plus, Trash2, X, Search, ClipboardList } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { DashboardLayout } from '../components/DashboardLayout';
import { BonLivraisonToolbar } from '../components/BonLivraisonToolbar';
import { BonLivraisonTable } from '../components/BonLivraisonTable';
import { BonLivraisonForm } from '../components/BonLivraisonForm';
import { BonLivraison } from '../types';

export const BonLivraisonPage: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();
  const [data, setData] = useState<BonLivraison[]>([]);
  const [view, setView] = useState<'list' | 'form'>('list');
  const [loading, setLoading] = useState(true);

  const isReception = location.pathname.includes('reception');
  const pageLabel = isReception ? "Bon de Réception" : "Bon de Livraison";
  const labelPrefix = isReception ? "BR" : "BL";

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await axios.get('/api/bon-livraison');
      const allData = Array.isArray(res.data) ? res.data : [];
      setData(allData.filter((d: BonLivraison) => d.reference && d.reference.startsWith(labelPrefix)));
    } catch (err) {
      console.error(err);
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [location.pathname]);

  const handleCreate = async (formData: any) => {
    try {
      const nextNumStr = getNextRef();
      const finalData = { 
        ...formData, 
        reference: `${labelPrefix}-${nextNumStr.padStart(5, '0')}`,
        date: new Date().toISOString(),
        validated: true,
        printedCount: 0
      };
      await axios.post('/api/bon-livraison', finalData);
      setView('list');
      fetchData();
    } catch (err) {
      console.error(err);
      alert("Erreur lors de la création");
    }
  };

  const getNextRef = () => {
    if (!Array.isArray(data) || data.length === 0) return "1";
    // Extract numbers from references that start with our current prefix
    const refs = data
      .filter(d => d.reference?.startsWith(labelPrefix))
      .map(d => {
        const parts = d.reference.split('-');
        return parseInt(parts[parts.length - 1]) || 0;
      });
    
    if (refs.length === 0) return "1";
    return (Math.max(...refs) + 1).toString();
  };

  const canAddBon = () => {
    if (view === 'form') return false;
    if (!Array.isArray(data) || data.length === 0) return true;
    
    // Check if the most recent bon of this type is NOT validated
    const latest = [...data]
      .filter(d => d.reference?.startsWith(labelPrefix))
      .sort((a, b) => {
        const partsA = a.reference.split('-');
        const numA = parseInt(partsA[partsA.length - 1]) || 0;
        const partsB = b.reference.split('-');
        const numB = parseInt(partsB[partsB.length - 1]) || 0;
        return numB - numA;
      })[0];
      
    if (latest && latest.validated === false) return false;
    return true;
  };

  return (
    <DashboardLayout title={pageLabel}>
      <div className="max-w-7xl mx-auto py-6 px-4">
        {view === 'list' ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-[24px] border border-slate-200 shadow-sm">
              <div>
                <h1 className="text-2xl font-serif font-bold text-slate-800">
                  📦 Liste des {pageLabel}s
                </h1>
                <p className="text-xs font-medium text-slate-400 mt-1">Gérez et consultez tous les {pageLabel.toLowerCase()}s enregistrés.</p>
              </div>
              <button 
                onClick={() => setView('form')}
                disabled={!canAddBon()}
                className={`flex items-center gap-2 px-8 py-3 rounded-full text-sm font-bold transition-all shadow-lg ${
                  !canAddBon()
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none' 
                    : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-700/20'
                }`}
              >
                <Plus size={18} />
                Ajouter un {pageLabel}
              </button>
            </div>

            <section className="bg-white rounded-[28px] border border-slate-200 shadow-xl overflow-hidden">
               {loading ? (
                 <div className="p-20 text-center animate-pulse text-slate-400">Chargement...</div>
               ) : (
                 <BonLivraisonTable data={data} onSelect={() => {}} />
               )}
            </section>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between mb-8 pb-4 border-b-2 border-dashed border-slate-200">
              <h2 className="text-2xl font-bold text-emerald-900 uppercase">
                📄 NOUVEAU {pageLabel} N° {getNextRef().padStart(5, '0')}
              </h2>
              <div className="flex items-center gap-4">
                <span className="text-xs font-bold bg-slate-100 px-4 py-1.5 rounded-full text-slate-500">
                  [Utilisateur : {user?.name || "Agent1"}]
                </span>
                <button 
                  onClick={() => setView('list')}
                  className="text-slate-400 hover:text-slate-600 transition-colors p-2"
                >
                  <X size={24} />
                </button>
              </div>
            </div>

            <BonLivraisonForm 
              initialData={{ reference: `${labelPrefix}-${getNextRef().padStart(5, '0')}` }}
              onCancel={() => setView('list')}
              onSubmit={handleCreate}
            />
          </motion.div>
        )}
      </div>
    </DashboardLayout>
  );
};
