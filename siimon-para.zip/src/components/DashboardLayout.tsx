/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BarChart3, 
  ShoppingBag, 
  Truck, 
  Users, 
  Package, 
  Settings, 
  LogOut,
  ChevronRight,
  ClipboardList,
  UserCircle,
  Percent,
  UserPlus,
  TruckIcon,
  MapPin,
  Tag,
  Warehouse,
  Layers,
  CreditCard,
  Building2,
  ListTree,
  Search,
  ChevronDown
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
  title: string;
}

export const DashboardLayout: React.FC<LayoutProps> = ({ children, title }) => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({
    'Ventes': location.pathname.includes('/vente'),
    'Achats': location.pathname.includes('/achat'),
    'Stocks': false,
    'Paramétrage': false,
    'Consultation': false
  });

  const toggleMenu = (name: string) => {
    setOpenMenus(prev => ({
      ...prev,
      [name]: !prev[name]
    }));
  };

  const menuItems = [
    { name: 'Tableau de bord', icon: <BarChart3 size={20} />, path: 'dashboard' },
    { name: 'Ventes', icon: <ShoppingBag size={20} />, submenu: [
      { name: 'Bons de Livraison', path: 'vente/bon-livraison' },
      { name: 'Factures Clients', path: 'vente/factures' },
      { name: 'Bon retour', path: 'vente/retour' },
      { name: 'Bon avoir', path: 'vente/avoir' },
      { name: 'Paiement', path: 'vente/paiement' },
      { name: 'Facture Automatique', path: 'vente/facture-auto' },
      { name: 'Suivi de livraison', path: 'vente/suivi' },
    ]},
    { name: 'Achats', icon: <Truck size={20} />, submenu: [
      { name: 'Demande de prix', path: 'achat/demande-prix' },
      { name: 'Bon de réception', path: 'achat/reception' },
      { name: 'Facture fournisseur', path: 'achat/factures' },
      { name: 'Retour fournisseur', path: 'achat/retour' },
      { name: 'Avoir fournisseur', path: 'achat/avoir' },
      { name: 'Paiement fournisseur', path: 'achat/paiement' },
    ]},
    { name: 'Stocks', icon: <Package size={20} />, submenu: [
      { name: 'Inventaire', path: 'stock/inventaire' },
      { name: 'Mouvement de stock', path: 'stock/mouvement' },
    ]},
    { name: 'Consultation', icon: <Search size={20} />, submenu: [
      { name: 'Etat de stock', path: 'cons/stock' },
      { name: 'Journal des ventes', path: 'cons/ventes' },
      { name: 'Relevé client', path: 'cons/releve' },
    ]},
    { name: 'Paramétrage', icon: <Settings size={20} />, submenu: [
      { name: 'Clients', path: 'param/clients' },
      { name: 'Fournisseurs', path: 'param/fournisseurs' },
      { name: 'Produits', path: 'param/produits' },
      { name: 'Articles & nomenclature', path: 'param/nomenclature' },
      { name: 'TVA', path: 'param/tva' },
      { name: 'Promotions', path: 'param/promotions' },
      { name: 'Users', path: 'param/users' },
      { name: 'Roles (RBAC)', path: 'param/roles' },
      { name: 'Livreurs', path: 'param/livreurs' },
      { name: 'Categorie client', path: 'param/cat-client' },
      { name: 'Zone', path: 'param/zone' },
      { name: 'Ville', path: 'param/ville' },
      { name: 'Group remise', path: 'param/group-remise' },
      { name: 'Depot', path: 'param/depot' },
      { name: 'Famille', path: 'param/famille' },
      { name: 'Sous famille', path: 'param/sous-famille' },
      { name: 'Mode de Paiment', path: 'param/mode-paiement' },
    ]},
  ];

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6">
          <div className="flex flex-col">
            <span className="text-xl font-serif font-bold tracking-tight text-emerald-800">
              Siimon-Para
            </span>
            <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">
              Business Suite
            </span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const isSubOpen = item.submenu && openMenus[item.name];
            const isActive = location.pathname === (item.path === 'dashboard' ? '/dashboard' : `/dashboard/${item.path}`);
            
            const content = (
              <div className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-all group cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className={`transition-colors ${isActive || isSubOpen ? 'text-emerald-800' : 'text-slate-400 group-hover:text-emerald-800'}`}>
                    {item.icon}
                  </div>
                  <span className={`text-sm font-medium transition-colors ${isActive || isSubOpen ? 'text-emerald-800' : 'text-slate-600 group-hover:text-emerald-800'}`}>
                    {item.name}
                  </span>
                </div>
                {item.submenu && (
                  <ChevronRight 
                    size={14} 
                    className={`transition-transform duration-200 ${
                      isSubOpen ? 'rotate-90 text-emerald-800' : 'text-slate-400 group-hover:text-emerald-800'
                    }`} 
                  />
                )}
              </div>
            );

            return (
              <div key={item.name}>
                {item.submenu ? (
                  <button onClick={() => toggleMenu(item.name)} className="w-full text-left">
                    {content}
                  </button>
                ) : (
                  <Link to={item.path === 'dashboard' ? '/dashboard' : `/dashboard/${item.path}`}>
                    {content}
                  </Link>
                )}
                <AnimatePresence>
                  {item.submenu && isSubOpen && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <div className="ml-9 mt-1 space-y-1 border-l border-slate-100 pl-2">
                        {item.submenu.map(sub => (
                          <Link 
                            key={sub.name} 
                            to={`/dashboard/${sub.path}`}
                            className={`w-full text-left block p-2 rounded-md text-xs font-medium transition-all ${
                              location.pathname.includes(sub.path) 
                                ? 'text-emerald-700 bg-emerald-50 font-bold' 
                                : 'text-slate-400 hover:text-emerald-700 hover:bg-emerald-50'
                            }`}
                          >
                            {sub.name}
                          </Link>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl mb-4">
            <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center text-white font-bold text-xs">
              {user?.name?.[0]}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-bold truncate">{user?.name}</p>
              <p className="text-[10px] text-slate-400 uppercase font-black">{user?.role}</p>
            </div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center gap-3 p-3 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-all"
          >
            <LogOut size={20} />
            <span className="text-sm font-medium">Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8">
          <h1 className="text-lg font-bold text-slate-800">{title}</h1>
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 text-xs font-medium text-slate-500 bg-slate-100 px-3 py-1.5 rounded-full">
               <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
               Système Actif
             </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {children}
          </motion.div>
        </div>
      </main>
    </div>
  );
};
