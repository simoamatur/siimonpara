import express from "express";
import { createServer as createViteServer } from "vite";
import { PrismaClient } from "@prisma/client";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import path from "path";
import fs from "fs";

const prisma = new PrismaClient();
const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "default_erp_secret";

app.use(express.json());

// Auth Middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(303); // Use 403 or similar, using 303 as placeholder for redirection logic if needed
    req.user = user;
    next();
  });
};

// --- AUTH ROUTES ---
app.post("/api/auth/register", async (req, res) => {
  const { email, password, name, role } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const user = await prisma.user.create({
      data: { email, password: hashedPassword, name, role: role || "USER" }
    });
    res.json({ id: user.id, email: user.email });
  } catch (e) {
    res.status(400).json({ error: "User already exists" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if (user && (await bcrypt.compare(password, user.password))) {
    const token = jwt.sign({ userId: user.id, role: user.role, name: user.name }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
});

// --- CLIENTS API ---
app.get("/api/clients", authenticateToken, async (req, res) => {
  try {
    const clients = await prisma.client.findMany();
    res.json(Array.isArray(clients) ? clients : []);
  } catch (error) {
    console.error("Prisma Clients Error:", error);
    res.status(500).json([]);
  }
});

app.post("/api/clients", authenticateToken, async (req, res) => {
  try {
    const client = await prisma.client.create({ data: req.body });
    res.json(client);
  } catch (error) {
    console.error("Create Client Error:", error);
    res.status(500).json({ error: "Failed to create client" });
  }
});

// --- PRODUCTS API ---
app.get("/api/products", authenticateToken, async (req, res) => {
  try {
    const products = await prisma.product.findMany();
    res.json(Array.isArray(products) ? products : []);
  } catch (error) {
    console.error("Prisma Products Error:", error);
    res.status(500).json([]);
  }
});

app.post("/api/products", authenticateToken, async (req, res) => {
  const product = await prisma.product.create({ data: req.body });
  res.json(product);
});

// --- BON DE LIVRAISON (BL) API ---
app.get("/api/bon-livraison", authenticateToken, async (req, res) => {
  const bls = await prisma.bonLivraison.findMany({
    include: { client: true, user: true },
    orderBy: { createdAt: 'desc' }
  });
  res.json(bls);
});

app.get("/api/bon-livraison/:id", authenticateToken, async (req, res) => {
  const bl = await prisma.bonLivraison.findUnique({
    where: { id: req.params.id },
    include: { client: true, items: { include: { product: true } } }
  });
  res.json(bl);
});

app.post("/api/bon-livraison", authenticateToken, async (req, res: any) => {
  const { clientId, items, paymentMode, reference, validated } = req.body;
  const userId = (req as any).user.userId;

  try {
    let finalRef = reference;

    if (!finalRef) {
      // Fallback auto-generation if not provided
      const lastBL = await prisma.bonLivraison.findFirst({
        orderBy: { createdAt: 'desc' }
      });
      
      let nextNum = 1;
      if (lastBL) {
        const parts = lastBL.reference.split("-");
        const lastNum = parseInt(parts[parts.length - 1]);
        if (!isNaN(lastNum)) nextNum = lastNum + 1;
      }
      finalRef = `BL-${nextNum.toString().padStart(5, '0')}`;
    }

    // Calculate totals
    let totalHT = 0;
    let totalTVA = 0;
    let totalTTC = 0;

    const blItems = items.map((item: any) => {
      const lineHT = (item.quantity || 0) * (item.priceHT || 0) * (1 - (item.discount || 0) / 100);
      const lineTVA = lineHT * ((item.tva || 0) / 100);
      const lineTTC = lineHT + lineTVA;

      totalHT += lineHT;
      totalTVA += lineTVA;
      totalTTC += lineTTC;

      return {
        productId: item.productId,
        quantity: item.quantity,
        priceHT: item.priceHT,
        discount: item.discount,
        tva: item.tva,
        totalHT: lineHT,
        totalTTC: lineTTC
      };
    });

    const result = await prisma.$transaction(async (tx) => {
      const bl = await tx.bonLivraison.create({
        data: {
          reference: finalRef,
          clientId,
          userId,
          paymentMode: paymentMode || "ESPÈCE",
          totalHT,
          totalTVA,
          totalTTC,
          validated: validated !== undefined ? validated : false,
          items: {
            create: blItems
          }
        },
        include: { items: true }
      });

      // Update Stock
      for (const item of blItems) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { decrement: item.quantity } }
        });
      }

      return bl;
    });

    res.json(result);
  } catch (error) {
    console.error("Prisma Error:", error);
    res.status(500).json({ error: "Failed to create bon", details: error instanceof Error ? error.message : String(error) });
  }
});

app.put("/api/bon-livraison/:id", authenticateToken, async (req, res) => {
  const { validated } = req.body;
  const bl = await prisma.bonLivraison.update({
    where: { id: req.params.id },
    data: { validated }
  });
  res.json(bl);
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ERP Server running on http://localhost:${PORT}`);
  });
}

startServer();
